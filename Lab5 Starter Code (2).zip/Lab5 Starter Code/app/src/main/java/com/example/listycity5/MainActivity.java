package com.example.listycity5;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    ListView cityList;
    ArrayList<City> cityDataList;
    CityArrayAdapter cityArrayAdapter;

    private EditText editCity;
    private EditText editProvince;
    private Button addCitiesButton;

    private FirebaseFirestore db;
    private CollectionReference citiesRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editCity = findViewById(R.id.city_name_edit);
        editProvince = findViewById(R.id.province_name_edit);
        addCityButton = findViewById(R.id.add_city_button);

        db = FirebaseFirestore.getInstance();
        citiesRef = db.collection("cities");

        cityList = findViewById(R.id.city_list);
        cityDataList = new ArrayList<>();

        cityArrayAdapter = new CityArrayAdapter(this, cityDataList);
        cityList.setAdapter(cityArrayAdapter);

        addCitiesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cityName = editCity.getText().toString();
                String provinceName = editProvince.getText().toString();

                if (cityName.isEmpty()) {
                    Toast.makeText(MainActivity.this, "City name cannot be empty", Toast.LENGTH_SHORT).show();
                } else if (provinceName.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Province name cannot be empty", Toast.LENGTH_SHORT).show();
                } else {
                    addNewCity(new City(cityName, provinceName));
                }
            }
        });


        citiesRef.addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot querySnapshots, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    Log.e("Firestore", error.toString());
                    return;
                }
                if (querySnapshots != null) {
                    cityDataList.clear();
                    for (QueryDocumentSnapshot doc: querySnapshots) {
                        String city = doc.getId();
                        String province = doc.getString("Province");
                        Log.d("Firestore", String.format("City(%s, %s) fetched", city, province));
                        cityDataList.add(new City(city, province));
                    }
                    cityArrayAdapter.notifyDataSetChanged();
                }
            }
        });
    }
    private void addNewCity(City city) {
        cityDataList.add(city);
        cityArrayAdapter.notifyDataSetChanged();

        HashMap<String, String> data = new HashMap<>();
        data.put("Province", city.getProvinceName());
        citiesRef.document(city.getCityName()).set(data);
    }
    private void deleteCity(City city){
        cityDataList.remove(city);
        cityArrayAdapter.notifyDataSetChanged();
        citiesRef.document(city.getCityName())
                .delete()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Log.d("Firestore", "City successfully deleted");
                    } else {
                        Log.e("Firestore", "Failed to delete city", task.getException());
                    }
                });
    }

    /**
     * Adds the initial city objects to the ArrayList
     */
    private void addCitiesInit() {
        String []cities ={"Edmonton", "Vancouver", "Toronto", "Hamilton", "Denver", "Los Angeles"};
        String []provinces = {"AB", "BC", "ON", "ON", "CO", "CA"};
        for(int i=0;i<cities.length;i++){
            cityDataList.add((new City(cities[i], provinces[i])));
        }
    }
}