package com.example.byungkoo_mybookwishlist;

import android.os.Bundle;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class cvMainActivity extends AppCompatActivity {
    private ArrayList<Book> bookList;
    private ListView bookListView;
    private BookArrayAdapter bookAdapter;

    public void addBook(Book book){
        bookAdapter.add(book);
        bookAdapter.notifyDataSetChanged();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        bookList = new ArrayList<>();
        String[] titles = { "The Great Gatsby", "1984", "To Kill a Mockingbird" };
        String[] authors = { "F. Scott Fitzgerald", "George Orwell", "Harper Lee" };
        String[] genres = { "Fiction", "Dystopian", "Fiction" };
        int[] years = { 1925, 1949, 1960 };

        for (int i = 0; i < titles.length; i++) {
            bookList.add(new Book(titles[i], authors[i], genres[i], years[i], "Unread"));
        }

        bookListView = findViewById(R.id.book_list);
        bookAdapter = new BookArrayAdapter(this, bookList);
        bookListView.setAdapter(bookAdapter);

        FloatingActionButton fab = findViewById(R.id.button_add_book);
        fab.setOnClickListener(v -> {
            new AddBookFragment().show(getSupportFragmentManager(), "Add Book");
        });
    }
}