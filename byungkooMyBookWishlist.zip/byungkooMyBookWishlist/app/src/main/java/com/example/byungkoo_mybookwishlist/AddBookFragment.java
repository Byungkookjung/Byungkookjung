package com.example.byungkoo_mybookwishlist;


import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class AddBookFragment extends DialogFragment {
    interface AddBookDialogListener {
        void addBook(Book book);
    }
    private AddBookDialogListener listener;


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof AddBookDialogListener) {
            listener = (AddBookDialogListener) context;
        } else {
            throw new RuntimeException(context + " must implement AddBookDialogListener");
        }
    }
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.fragment_add_book, null);
        EditText editTitle = view.findViewById(R.id.edit_text_Book_title_text);
        EditText editAuthor = view.findViewById(R.id.edit_text_Author_name_text);
        EditText editYear = view.findViewById(R.id.edit_text_Publication_year_text);
        EditText editGenre = view.findViewById(R.id.edit_text_Genre_text);
        EditText editStatus = view.findViewById(R.id.edit_text_Status_text);

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        return builder
                .setView(view)
                .setTitle("Add to your Wishlist" : "Edit your wishlist")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add", (dialog, which) -> {
                    String newTitle = editCityName.getText().toString();
                    String provinceName = editStatus.getText().toString();
                    listener.addBook(new Book(cityName, provinceName));
                })
                .create();
    }
}