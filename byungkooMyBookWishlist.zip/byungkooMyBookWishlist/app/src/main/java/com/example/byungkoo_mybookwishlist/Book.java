package com.example.byungkoo_mybookwishlist;

public class Book {
    private String title;
    private String author;
    private String genre;
    private String status;
    private boolean year;

    public Book(String title, String author, String genre, boolean year, String status) {
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.year = year;
        this.status = status;
    }
    public String getTitle() {
        return title;
    }
    public String getAuthor() {
        return author;
    }
    public String getGenre() {
        return genre;
    }
    public boolean getYear() {
        return year;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
