package com.example.byungkoo_mybookwishlist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import androidx.annotation.NonNull;


import java.util.ArrayList;

public class BookArrayAdapter extends ArrayAdapter<Book> {

    public BookArrayAdapter(Context context, ArrayList<Book> books) {
        super(context, 0, books);  // Use "books" instead of "cities"
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.content, parent, false);
        }

        // Get the data item for this position
        Book book = getItem(position);

        // Lookup view for data population
        TextView bookTitle = convertView.findViewById(R.id.book_text);
        TextView authorName = convertView.findViewById(R.id.author_text);
        TextView genre = convertView.findViewById(R.id.genre_text);
        TextView readStatus = convertView.findViewById(R.id.publication_year_text);

        // Populate the data into the template view using the data object
        bookTitle.setText(book.getTitle());
        authorName.setText(book.getAuthor());
        genre.setText(book.getGenre());
        readStatus.setText(book.getRead_status() ? "Read" : "Unread");

        // Return the completed view to render on screen
        return convertView;
    }

}


