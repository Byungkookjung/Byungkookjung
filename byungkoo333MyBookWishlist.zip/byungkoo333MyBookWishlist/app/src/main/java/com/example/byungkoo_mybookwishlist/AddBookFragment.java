package com.example.byungkoo_mybookwishlist;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;



import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class AddBookFragment extends DialogFragment {
    interface AddBookDialogListener {
        void addBook(Book book);
    }
    private AddBookDialogListener listener;
    private boolean isRead = false;  // Tracks whether the book is read or not

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof AddBookDialogListener) {
            listener = (AddBookDialogListener) context;
        } else {
            throw new RuntimeException(context + " must implement AddBookDialogListener");
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.fragment_add_book, null);
        EditText editBookName = view.findViewById(R.id.edit_text_book_title_text);
        EditText editAuthorName = view.findViewById(R.id.edit_text_author_name_text);
        EditText editGenre = view.findViewById(R.id.edit_text_genre_text);
        EditText editPublicationYear = view.findViewById(R.id.edit_text_publication_year_text);
        Button readStatusButton = view.findViewById(R.id.button_read_status);

        // Initialize button text
        readStatusButton.setText("Mark as Read");

        // Toggle read status when button is clicked
        readStatusButton.setOnClickListener(v -> {
            isRead = !isRead;  // Toggle the boolean value
            if (isRead) {
                readStatusButton.setText("Marked as Read");
            } else {
                readStatusButton.setText("Mark as Read");
            }
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        return builder
                .setView(view)
                .setTitle("Add a book")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add", (dialog, which) -> {
                    String bookName = editBookName.getText().toString();
                    String authorName = editAuthorName.getText().toString();
                    String genre = editGenre.getText().toString();
                    int publicationYear = Integer.parseInt(editPublicationYear.getText().toString());

                    // Pass the book object with the isRead status
                    listener.addBook(new Book(bookName, authorName, genre, publicationYear, isRead));
                })
                .create();
    }
}