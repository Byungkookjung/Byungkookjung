package com.example.byungkoo_mybookwishlist;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class ViewDetailsFragment extends DialogFragment {
    private Book book;

    // Factory method to create a new instance of ViewDetailsFragment with the Book data
    public static ViewDetailsFragment newInstance(Book book) {
        ViewDetailsFragment fragment = new ViewDetailsFragment();
        Bundle args = new Bundle();
        args.putSerializable("book", book);
        fragment.setArguments(args);  // Attach the book as arguments
        return fragment;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_view_details, container, false);

        // Retrieve the Book object from the arguments
        if (getArguments() != null) {
            book = (Book) getArguments().getSerializable("book");
        }

        // Get references to the TextViews in the layout
        TextView bookNameTextView = view.findViewById(R.id.text_view_book_name);
        TextView authorTextView = view.findViewById(R.id.text_view_author);
        TextView genreTextView = view.findViewById(R.id.text_view_genre);
        TextView publicationYearTextView = view.findViewById(R.id.text_view_publication_year);
        TextView statusTextView = view.findViewById(R.id.text_view_status);

        // Set the book details to the TextViews
        if (book != null) {
            bookNameTextView.setText(book.getTitle());
            authorTextView.setText(book.getAuthor());
            genreTextView.setText(book.getGenre());
            publicationYearTextView.setText(String.valueOf(book.getPublication_year()));
            statusTextView.setText(book.getRead_status() ? "Read" : "Unread");
        }

        return view;
    }
}
